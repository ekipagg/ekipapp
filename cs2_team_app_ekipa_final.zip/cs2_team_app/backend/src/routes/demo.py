from flask import Blueprint, request, jsonify, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from src.models.user import db, Demo, DemoAnalysis, PlayerStats
import os
import json
import random
from datetime import datetime

demo_bp = Blueprint('demo', __name__)

ALLOWED_EXTENSIONS = {'dem'}
UPLOAD_FOLDER = 'uploads/demos'

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@demo_bp.route('/upload', methods=['POST'])
@login_required
def upload_demo():
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'Nenhum ficheiro enviado'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Nenhum ficheiro selecionado'}), 400
        
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            # Adicionar timestamp para evitar conflitos
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
            unique_filename = timestamp + filename
            
            # Criar diretório se não existir
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
            
            file_path = os.path.join(UPLOAD_FOLDER, unique_filename)
            file.save(file_path)
            
            # Criar entrada na base de dados
            demo = Demo(
                filename=unique_filename,
                original_filename=file.filename,
                file_path=file_path,
                team_type=request.form.get('team_type', 'own'),
                uploaded_by=current_user.id
            )
            
            db.session.add(demo)
            db.session.commit()
            
            return jsonify({
                'success': True,
                'message': 'Demo enviado com sucesso',
                'demo': demo.to_dict()
            }), 201
        else:
            return jsonify({'success': False, 'error': 'Tipo de ficheiro não permitido. Apenas ficheiros .dem são aceites'}), 400
            
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@demo_bp.route('/', methods=['GET'])
@login_required
def get_demos():
    try:
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 10, type=int)
        team_type = request.args.get('team_type')
        search = request.args.get('search', '')
        
        query = Demo.query
        
        if team_type and team_type != 'all':
            query = query.filter_by(team_type=team_type)
        
        if search:
            query = query.filter(Demo.original_filename.contains(search))
        
        demos = query.order_by(Demo.uploaded_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'success': True,
            'demos': [demo.to_dict() for demo in demos.items],
            'total': demos.total,
            'pages': demos.pages,
            'current_page': page
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@demo_bp.route('/<int:demo_id>', methods=['GET'])
@login_required
def get_demo(demo_id):
    try:
        demo = Demo.query.get_or_404(demo_id)
        return jsonify({'success': True, 'demo': demo.to_dict()}), 200
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@demo_bp.route('/<int:demo_id>/analyze', methods=['POST'])
@login_required
def analyze_demo(demo_id):
    try:
        demo = Demo.query.get_or_404(demo_id)
        
        # Verificar se o utilizador tem permissão
        if demo.uploaded_by != current_user.id and current_user.role not in ['captain', 'analyst']:
            return jsonify({'success': False, 'error': 'Sem permissão'}), 403
        
        # Gerar análise simulada
        analysis_data = generate_mock_analysis()
        
        # Criar ou atualizar análise
        analysis = DemoAnalysis.query.filter_by(demo_id=demo_id).first()
        if not analysis:
            analysis = DemoAnalysis(
                demo_id=demo_id,
                analysis_data=json.dumps(analysis_data)
            )
            db.session.add(analysis)
        else:
            analysis.analysis_data = json.dumps(analysis_data)
            analysis.analyzed_at = datetime.utcnow()
        
        # Eliminar estatísticas antigas
        PlayerStats.query.filter_by(demo_id=demo_id).delete()
        
        # Criar novas estatísticas de jogadores
        for player_data in analysis_data['players']:
            stats = PlayerStats(
                demo_id=demo_id,
                player_name=player_data['name'],
                kills=player_data['kills'],
                deaths=player_data['deaths'],
                assists=player_data['assists'],
                adr=player_data['adr'],
                headshot_percentage=player_data['headshot_percentage'],
                utility_usage=json.dumps({
                    'smokes': random.randint(1, 5),
                    'flashes': random.randint(3, 12),
                    'he_grenades': random.randint(0, 4),
                    'molotovs': random.randint(0, 3)
                })
            )
            db.session.add(stats)
        
        demo.is_analyzed = True
        demo.map_name = analysis_data['map_name']
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'message': 'Demo analisado com sucesso',
            'analysis': analysis_data
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@demo_bp.route('/<int:demo_id>/stats', methods=['GET'])
@login_required
def get_demo_stats(demo_id):
    try:
        demo = Demo.query.get_or_404(demo_id)
        analysis = DemoAnalysis.query.filter_by(demo_id=demo_id).first()
        
        if not analysis:
            return jsonify({'success': False, 'error': 'Demo ainda não foi analisado'}), 404
        
        analysis_data = json.loads(analysis.analysis_data)
        
        return jsonify({
            'success': True,
            'demo': demo.to_dict(),
            'stats': analysis_data
        }), 200
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@demo_bp.route('/<int:demo_id>', methods=['DELETE'])
@login_required
def delete_demo(demo_id):
    try:
        demo = Demo.query.get_or_404(demo_id)
        
        # Verificar se o utilizador tem permissão para eliminar
        if demo.uploaded_by != current_user.id and current_user.role not in ['captain', 'analyst']:
            return jsonify({'success': False, 'error': 'Sem permissão para eliminar este demo'}), 403
        
        # Eliminar ficheiro físico
        if os.path.exists(demo.file_path):
            os.remove(demo.file_path)
        
        # Eliminar análise e estatísticas
        DemoAnalysis.query.filter_by(demo_id=demo_id).delete()
        PlayerStats.query.filter_by(demo_id=demo_id).delete()
        
        # Eliminar da base de dados
        db.session.delete(demo)
        db.session.commit()
        
        return jsonify({'success': True, 'message': 'Demo eliminado com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

def generate_mock_analysis():
    """Gerar dados de análise simulados para demonstração"""
    maps = ['de_dust2', 'de_mirage', 'de_inferno', 'de_cache', 'de_overpass', 'de_nuke', 'de_train']
    
    players = [
        {'name': 'Player1', 'steam_id': '76561198000000001'},
        {'name': 'Player2', 'steam_id': '76561198000000002'},
        {'name': 'Player3', 'steam_id': '76561198000000003'},
        {'name': 'Player4', 'steam_id': '76561198000000004'},
        {'name': 'Player5', 'steam_id': '76561198000000005'},
    ]
    
    # Gerar estatísticas para cada jogador
    for player in players:
        kills = random.randint(8, 35)
        deaths = random.randint(5, 30)
        assists = random.randint(1, 20)
        
        player.update({
            'kills': kills,
            'deaths': deaths,
            'assists': assists,
            'adr': round(random.uniform(50, 130), 1),
            'rating': round(random.uniform(0.6, 1.8), 2),
            'headshot_percentage': round(random.uniform(15, 70), 1),
            'kd_ratio': round(kills / max(deaths, 1), 2)
        })
    
    # Estatísticas gerais
    total_kills = sum(p['kills'] for p in players)
    total_headshots = int(total_kills * random.uniform(0.25, 0.55))
    
    # Gerar dados de rounds
    team_score = random.randint(10, 16)
    enemy_score = random.randint(6, 16)
    total_rounds = team_score + enemy_score
    
    rounds_data = []
    current_team = 0
    current_enemy = 0
    
    for i in range(total_rounds):
        if random.random() < (team_score / total_rounds):
            current_team += 1
            won = True
        else:
            current_enemy += 1
            won = False
        
        rounds_data.append({
            'round_number': i + 1,
            'team_score': current_team,
            'enemy_score': current_enemy,
            'won': won
        })
    
    analysis = {
        'map_name': random.choice(maps),
        'final_score': {
            'team_score': team_score,
            'enemy_score': enemy_score,
            'result': 'Vitória' if team_score > enemy_score else 'Derrota' if team_score < enemy_score else 'Empate'
        },
        'total_kills': total_kills,
        'total_headshots': total_headshots,
        'average_adr': round(sum(p['adr'] for p in players) / len(players), 1),
        'average_rating': round(sum(p['rating'] for p in players) / len(players), 2),
        'players': players,
        'rounds': rounds_data,
        'weapon_stats': {
            'AK-47': {'kills': random.randint(12, 28), 'accuracy': random.randint(22, 48)},
            'M4A4': {'kills': random.randint(8, 22), 'accuracy': random.randint(28, 52)},
            'M4A1-S': {'kills': random.randint(6, 18), 'accuracy': random.randint(30, 55)},
            'AWP': {'kills': random.randint(3, 18), 'accuracy': random.randint(55, 85)},
            'Glock-18': {'kills': random.randint(1, 8), 'accuracy': random.randint(18, 38)},
            'USP-S': {'kills': random.randint(1, 8), 'accuracy': random.randint(22, 42)},
            'Deagle': {'kills': random.randint(0, 6), 'accuracy': random.randint(15, 35)}
        },
        'utility_usage': {
            'smokes': random.randint(12, 35),
            'flashes': random.randint(18, 45),
            'he_grenades': random.randint(6, 28),
            'molotovs': random.randint(4, 22)
        },
        'insights': [
            {
                'title': 'Performance Destacada',
                'description': f'{max(players, key=lambda x: x["rating"])["name"]} teve uma performance excelente com rating {max(players, key=lambda x: x["rating"])["rating"]}.'
            },
            {
                'title': 'Uso de Utilitários',
                'description': 'A equipa fez bom uso de smokes e flashes. Considere coordenar melhor o uso de molotovs para controlo de área.'
            },
            {
                'title': 'Economia',
                'description': 'Boa gestão económica observada. Mantenham o foco em eco rounds para maximizar as compras completas.'
            },
            {
                'title': 'Posicionamento',
                'description': 'Considere variar mais as posições defensivas para surpreender os adversários e evitar reads.'
            }
        ]
    }
    
    return analysis

