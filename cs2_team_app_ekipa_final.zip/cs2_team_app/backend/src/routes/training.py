from flask import Blueprint, request, jsonify
from flask_login import login_required, current_user
from src.models.user import db, User, Availability, TrainingSession, training_participants
from datetime import datetime, date, time
import json

training_bp = Blueprint('training', __name__)

@training_bp.route('/availability', methods=['POST'])
@login_required
def set_availability():
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        if not data.get('date') or not data.get('start_time') or not data.get('end_time'):
            return jsonify({'error': 'Data, hora de início e fim são obrigatórias'}), 400
        
        # Converter strings para objetos de data/hora
        availability_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
        start_time = datetime.strptime(data['start_time'], '%H:%M').time()
        end_time = datetime.strptime(data['end_time'], '%H:%M').time()
        
        # Verificar se já existe disponibilidade para esta data
        existing = Availability.query.filter_by(
            user_id=current_user.id,
            date=availability_date
        ).first()
        
        if existing:
            # Atualizar disponibilidade existente
            existing.start_time = start_time
            existing.end_time = end_time
        else:
            # Criar nova disponibilidade
            availability = Availability(
                user_id=current_user.id,
                date=availability_date,
                start_time=start_time,
                end_time=end_time
            )
            db.session.add(availability)
        
        db.session.commit()
        
        return jsonify({'message': 'Disponibilidade definida com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@training_bp.route('/availability', methods=['GET'])
@login_required
def get_availability():
    try:
        user_id = request.args.get('user_id', current_user.id, type=int)
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        query = Availability.query.filter_by(user_id=user_id)
        
        if start_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%d').date()
            query = query.filter(Availability.date >= start_date)
        
        if end_date:
            end_date = datetime.strptime(end_date, '%Y-%m-%d').date()
            query = query.filter(Availability.date <= end_date)
        
        availabilities = query.order_by(Availability.date).all()
        
        return jsonify({
            'availabilities': [av.to_dict() for av in availabilities]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@training_bp.route('/sessions', methods=['POST'])
@login_required
def create_training_session():
    try:
        # Verificar se o utilizador tem permissão para criar sessões
        if current_user.role not in ['captain', 'analyst']:
            return jsonify({'error': 'Sem permissão para criar sessões de treino'}), 403
        
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['title', 'session_type', 'start_datetime', 'end_datetime']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'{field} é obrigatório'}), 400
        
        # Converter strings para objetos datetime
        start_datetime = datetime.fromisoformat(data['start_datetime'].replace('Z', '+00:00'))
        end_datetime = datetime.fromisoformat(data['end_datetime'].replace('Z', '+00:00'))
        
        # Criar sessão de treino
        session = TrainingSession(
            title=data['title'],
            description=data.get('description'),
            session_type=data['session_type'],
            start_datetime=start_datetime,
            end_datetime=end_datetime,
            created_by=current_user.id
        )
        
        db.session.add(session)
        db.session.flush()  # Para obter o ID da sessão
        
        # Adicionar participantes se especificados
        if data.get('participant_ids'):
            for user_id in data['participant_ids']:
                user = User.query.get(user_id)
                if user:
                    session.participants.append(user)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Sessão de treino criada com sucesso',
            'session': session.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@training_bp.route('/sessions', methods=['GET'])
@login_required
def get_training_sessions():
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        session_type = request.args.get('session_type')
        
        query = TrainingSession.query
        
        if start_date:
            start_date = datetime.strptime(start_date, '%Y-%m-%d')
            query = query.filter(TrainingSession.start_datetime >= start_date)
        
        if end_date:
            end_date = datetime.strptime(end_date, '%Y-%m-%d')
            query = query.filter(TrainingSession.start_datetime <= end_date)
        
        if session_type:
            query = query.filter_by(session_type=session_type)
        
        sessions = query.order_by(TrainingSession.start_datetime).all()
        
        return jsonify({
            'sessions': [session.to_dict() for session in sessions]
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@training_bp.route('/sessions/<int:session_id>', methods=['PUT'])
@login_required
def update_training_session(session_id):
    try:
        session = TrainingSession.query.get_or_404(session_id)
        
        # Verificar permissões
        if session.created_by != current_user.id and current_user.role not in ['captain', 'analyst']:
            return jsonify({'error': 'Sem permissão para editar esta sessão'}), 403
        
        data = request.get_json()
        
        # Atualizar campos se fornecidos
        if data.get('title'):
            session.title = data['title']
        if data.get('description'):
            session.description = data['description']
        if data.get('session_type'):
            session.session_type = data['session_type']
        if data.get('start_datetime'):
            session.start_datetime = datetime.fromisoformat(data['start_datetime'].replace('Z', '+00:00'))
        if data.get('end_datetime'):
            session.end_datetime = datetime.fromisoformat(data['end_datetime'].replace('Z', '+00:00'))
        
        # Atualizar participantes se fornecidos
        if 'participant_ids' in data:
            session.participants.clear()
            for user_id in data['participant_ids']:
                user = User.query.get(user_id)
                if user:
                    session.participants.append(user)
        
        db.session.commit()
        
        return jsonify({
            'message': 'Sessão atualizada com sucesso',
            'session': session.to_dict()
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@training_bp.route('/sessions/<int:session_id>', methods=['DELETE'])
@login_required
def delete_training_session(session_id):
    try:
        session = TrainingSession.query.get_or_404(session_id)
        
        # Verificar permissões
        if session.created_by != current_user.id and current_user.role not in ['captain', 'analyst']:
            return jsonify({'error': 'Sem permissão para eliminar esta sessão'}), 403
        
        db.session.delete(session)
        db.session.commit()
        
        return jsonify({'message': 'Sessão eliminada com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@training_bp.route('/suggest-schedule', methods=['POST'])
@login_required
def suggest_schedule():
    try:
        # Verificar permissões
        if current_user.role not in ['captain', 'analyst']:
            return jsonify({'error': 'Sem permissão para sugerir horários'}), 403
        
        data = request.get_json()
        target_date = datetime.strptime(data['date'], '%Y-%m-%d').date()
        duration_hours = data.get('duration_hours', 2)
        
        # Obter todas as disponibilidades para a data
        availabilities = Availability.query.filter_by(date=target_date).all()
        
        if not availabilities:
            return jsonify({'suggestions': []}), 200
        
        # Algoritmo simples para encontrar sobreposições
        # Em produção, seria mais sofisticado
        suggestions = []
        
        # Agrupar por horários comuns
        time_slots = {}
        for av in availabilities:
            start_hour = av.start_time.hour
            end_hour = av.end_time.hour
            
            for hour in range(start_hour, end_hour):
                if hour not in time_slots:
                    time_slots[hour] = []
                time_slots[hour].append(av.user_id)
        
        # Encontrar slots com mais utilizadores disponíveis
        for hour, users in time_slots.items():
            if len(users) >= 3:  # Mínimo 3 jogadores
                suggestions.append({
                    'start_time': f"{hour:02d}:00",
                    'end_time': f"{hour + duration_hours:02d}:00",
                    'available_users': len(users),
                    'user_ids': users
                })
        
        # Ordenar por número de utilizadores disponíveis
        suggestions.sort(key=lambda x: x['available_users'], reverse=True)
        
        return jsonify({'suggestions': suggestions[:5]}), 200  # Top 5 sugestões
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

