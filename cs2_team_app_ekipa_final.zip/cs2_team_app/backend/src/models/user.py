from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime

db = SQLAlchemy()

# Tabela de associação para participantes de sessões de treino
training_participants = db.Table("training_participants",
    db.Column("training_session_id", db.Integer, db.ForeignKey("training_session.id"), primary_key=True),
    db.Column("user_id", db.Integer, db.ForeignKey("user.id"), primary_key=True)
)

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(20), nullable=False, default="player")  # player, captain, analyst
    steam_id = db.Column(db.String(50), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)
    is_active = db.Column(db.Boolean, default=True)

    # Relacionamentos
    demos = db.relationship("Demo", backref="uploader", lazy=True)
    availabilities = db.relationship("Availability", backref="user", lazy=True)
    training_sessions = db.relationship("TrainingSession", secondary="training_participants", backref="participants")

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f"<User {self.username}>"

    def to_dict(self):
        return {
            "id": self.id,
            "username": self.username,
            "email": self.email,
            "role": self.role,
            "steam_id": self.steam_id,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "is_active": self.is_active
        }

class Demo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    map_name = db.Column(db.String(100), nullable=True)
    match_date = db.Column(db.DateTime, nullable=True)
    team_type = db.Column(db.String(20), nullable=False)  # "own" or "opponent"
    uploaded_at = db.Column(db.DateTime, default=datetime.utcnow)
    uploaded_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    is_analyzed = db.Column(db.Boolean, default=False)
    
    # Relacionamentos
    analyses = db.relationship("DemoAnalysis", backref="demo", lazy=True)

    def to_dict(self):
        return {
            "id": self.id,
            "filename": self.filename,
            "original_filename": self.original_filename,
            "map_name": self.map_name,
            "match_date": self.match_date.isoformat() if self.match_date else None,
            "team_type": self.team_type,
            "uploaded_at": self.uploaded_at.isoformat(),
            "uploaded_by": self.uploaded_by,
            "is_analyzed": self.is_analyzed
        }

class DemoAnalysis(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    demo_id = db.Column(db.Integer, db.ForeignKey("demo.id"), nullable=False)
    analysis_data = db.Column(db.Text, nullable=False)  # JSON string
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "demo_id": self.demo_id,
            "analysis_data": self.analysis_data,
            "created_at": self.created_at.isoformat()
        }

class PlayerStats(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    demo_id = db.Column(db.Integer, db.ForeignKey("demo.id"), nullable=False)
    player_name = db.Column(db.String(100), nullable=False)
    steam_id = db.Column(db.String(50), nullable=True)
    kills = db.Column(db.Integer, default=0)
    deaths = db.Column(db.Integer, default=0)
    assists = db.Column(db.Integer, default=0)
    adr = db.Column(db.Float, default=0.0)
    headshot_percentage = db.Column(db.Float, default=0.0)
    utility_usage = db.Column(db.Text, nullable=True)  # JSON string
    
    def to_dict(self):
        return {
            "id": self.id,
            "demo_id": self.demo_id,
            "player_name": self.player_name,
            "steam_id": self.steam_id,
            "kills": self.kills,
            "deaths": self.deaths,
            "assists": self.assists,
            "adr": self.adr,
            "headshot_percentage": self.headshot_percentage,
            "utility_usage": self.utility_usage
        }

class Availability(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    date = db.Column(db.Date, nullable=False)
    start_time = db.Column(db.Time, nullable=False)
    end_time = db.Column(db.Time, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "user_id": self.user_id,
            "date": self.date.isoformat(),
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "created_at": self.created_at.isoformat()
        }

class TrainingSession(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=True)
    session_type = db.Column(db.String(50), nullable=False)  # "training", "scrim", "tournament"
    start_datetime = db.Column(db.DateTime, nullable=False)
    end_datetime = db.Column(db.DateTime, nullable=False)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "description": self.description,
            "session_type": self.session_type,
            "start_datetime": self.start_datetime.isoformat(),
            "end_datetime": self.end_datetime.isoformat(),
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat(),
            "participants": [p.to_dict() for p in self.participants]
        }

class Tactic(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    map_name = db.Column(db.String(100), nullable=False)
    side = db.Column(db.String(10), nullable=False)  # "T" or "CT"
    description = db.Column(db.Text, nullable=True)
    setup_data = db.Column(db.Text, nullable=False)  # JSON string with positions, utilities, etc.
    success_rate = db.Column(db.Float, default=0.0)
    usage_count = db.Column(db.Integer, default=0)
    created_by = db.Column(db.Integer, db.ForeignKey("user.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            "id": self.id,
            "name": self.name,
            "map_name": self.map_name,
            "side": self.side,
            "description": self.description,
            "setup_data": self.setup_data,
            "success_rate": self.success_rate,
            "usage_count": self.usage_count,
            "created_by": self.created_by,
            "created_at": self.created_at.isoformat()
        }



