# Guia de Deployment - CS2 Team Manager

Este guia explica como fazer o deployment da aplicação CS2 Team Manager em diferentes plataformas.

## 🌐 Deployment Atual

**URL de Produção:** https://9yhyi3cq3vem.manus.space

A aplicação está atualmente deployada na plataforma Manus com todas as funcionalidades operacionais.

## 🚀 Opções de Deployment

### 1. Manus Platform (Atual)
A aplicação está deployada usando o serviço Manus, que oferece:
- URL permanente e HTTPS automático
- Deployment automático a partir do código
- Escalabilidade automática
- Monitorização integrada

### 2. Vercel (Frontend + Serverless)
Para deployment no Vercel:

```bash
# 1. Build do frontend
cd frontend
npm run build

# 2. Configurar vercel.json
{
  "builds": [
    {
      "src": "backend/src/main.py",
      "use": "@vercel/python"
    },
    {
      "src": "frontend/package.json",
      "use": "@vercel/static-build"
    }
  ],
  "routes": [
    {
      "src": "/api/(.*)",
      "dest": "backend/src/main.py"
    },
    {
      "src": "/(.*)",
      "dest": "frontend/dist/$1"
    }
  ]
}

# 3. Deploy
vercel --prod
```

### 3. Netlify (Frontend) + Railway (Backend)

#### Frontend no Netlify:
```bash
# 1. Build
cd frontend
npm run build

# 2. Configurar _redirects
echo "/* /index.html 200" > dist/_redirects

# 3. Deploy
netlify deploy --prod --dir=dist
```

#### Backend no Railway:
```bash
# 1. Criar railway.json
{
  "build": {
    "builder": "NIXPACKS"
  },
  "deploy": {
    "startCommand": "python src/main.py",
    "healthcheckPath": "/api/auth/check"
  }
}

# 2. Deploy
railway login
railway link
railway up
```

### 4. Docker + Cloud Providers

#### Dockerfile para Backend:
```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY backend/requirements.txt .
RUN pip install -r requirements.txt

COPY backend/ .
COPY frontend/dist/ src/static/

EXPOSE 5001

CMD ["python", "src/main.py"]
```

#### Docker Compose:
```yaml
version: '3.8'
services:
  cs2-app:
    build: .
    ports:
      - "5001:5001"
    environment:
      - FLASK_ENV=production
      - SECRET_KEY=your-production-secret-key
    volumes:
      - ./uploads:/app/uploads
      - ./database:/app/database
```

### 5. VPS/Servidor Dedicado

#### Configuração com Nginx + Gunicorn:

```bash
# 1. Instalar dependências
sudo apt update
sudo apt install python3-pip nginx

# 2. Configurar aplicação
cd /var/www/cs2-team-app
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
pip install gunicorn

# 3. Configurar Gunicorn
gunicorn --bind 0.0.0.0:5001 src.main:app

# 4. Configurar Nginx
sudo nano /etc/nginx/sites-available/cs2-team-app
```

#### Configuração Nginx:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:5001;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }

    location /static {
        alias /var/www/cs2-team-app/src/static;
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

## 🔧 Configurações de Produção

### Variáveis de Ambiente
```bash
# Backend
export FLASK_ENV=production
export SECRET_KEY=your-super-secret-production-key
export DATABASE_URL=postgresql://user:pass@host:port/dbname
export UPLOAD_FOLDER=/app/uploads
export MAX_CONTENT_LENGTH=104857600  # 100MB

# Frontend
export REACT_APP_API_URL=https://your-api-domain.com
export REACT_APP_ENV=production
```

### Base de Dados de Produção
Para produção, recomenda-se migrar de SQLite para PostgreSQL:

```python
# requirements.txt
psycopg2-binary==2.9.7

# main.py
import os
DATABASE_URL = os.environ.get('DATABASE_URL', 'sqlite:///database/app.db')
app.config['SQLALCHEMY_DATABASE_URI'] = DATABASE_URL
```

### Segurança
```python
# Configurações de segurança para produção
app.config.update(
    SECRET_KEY=os.environ.get('SECRET_KEY'),
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE='Lax',
    PERMANENT_SESSION_LIFETIME=timedelta(hours=24)
)
```

## 📊 Monitorização

### Health Checks
```python
@app.route('/health')
def health_check():
    return {
        'status': 'healthy',
        'timestamp': datetime.utcnow().isoformat(),
        'version': '1.0.0'
    }
```

### Logging
```python
import logging
from logging.handlers import RotatingFileHandler

if not app.debug:
    file_handler = RotatingFileHandler('logs/cs2-app.log', maxBytes=10240, backupCount=10)
    file_handler.setFormatter(logging.Formatter(
        '%(asctime)s %(levelname)s: %(message)s [in %(pathname)s:%(lineno)d]'
    ))
    file_handler.setLevel(logging.INFO)
    app.logger.addHandler(file_handler)
```

## 🔄 CI/CD Pipeline

### GitHub Actions:
```yaml
name: Deploy CS2 Team Manager

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      
      - name: Setup Node.js
        uses: actions/setup-node@v3
        with:
          node-version: '18'
          
      - name: Build Frontend
        run: |
          cd frontend
          npm install
          npm run build
          
      - name: Setup Python
        uses: actions/setup-python@v4
        with:
          python-version: '3.11'
          
      - name: Install Backend Dependencies
        run: |
          cd backend
          pip install -r requirements.txt
          
      - name: Deploy to Production
        run: |
          # Comandos específicos da plataforma de deployment
```

## 📋 Checklist de Deployment

### Antes do Deployment:
- [ ] Testar aplicação localmente
- [ ] Configurar variáveis de ambiente
- [ ] Atualizar URLs da API no frontend
- [ ] Configurar base de dados de produção
- [ ] Implementar backup de dados
- [ ] Configurar SSL/HTTPS
- [ ] Testar uploads de ficheiros
- [ ] Verificar limites de tamanho de ficheiro

### Após o Deployment:
- [ ] Verificar todas as rotas funcionam
- [ ] Testar autenticação e autorização
- [ ] Verificar upload e análise de demos
- [ ] Testar agendamento de treinos
- [ ] Confirmar responsividade mobile
- [ ] Configurar monitorização
- [ ] Documentar URLs e credenciais

## 🆘 Troubleshooting

### Problemas Comuns:

1. **CORS Errors:**
   ```python
   CORS(app, origins=['https://your-frontend-domain.com'])
   ```

2. **File Upload Issues:**
   ```python
   app.config['MAX_CONTENT_LENGTH'] = 100 * 1024 * 1024  # 100MB
   ```

3. **Database Connection:**
   ```python
   # Verificar se a base de dados está acessível
   with app.app_context():
       db.create_all()
   ```

4. **Static Files:**
   ```python
   # Verificar se os ficheiros estáticos estão no local correto
   app.static_folder = 'static'
   ```

## 📞 Suporte

Para questões relacionadas com deployment:
1. Verificar logs da aplicação
2. Confirmar configurações de ambiente
3. Testar conectividade de rede
4. Validar permissões de ficheiros

---

**Nota:** Este guia cobre as principais opções de deployment. Escolha a que melhor se adequa às suas necessidades e recursos disponíveis.

