# CS2 Team Manager

Uma aplicação web completa para gestão de equipas semi-profissionais de Counter-Strike 2, desenvolvida com Flask (backend) e React (frontend).

## 🚀 URL de Produção

**Aplicação Deployada:** https://9yhyi3cq3vem.manus.space

### Credenciais de Teste
- **Username:** admin
- **Password:** admin123
- **Função:** Captain

## 📋 Funcionalidades

### 🔐 Sistema de Autenticação
- Registo e login seguro de utilizadores
- Gestão de sessões com Flask-Login
- Três níveis de acesso: Player, Captain, Analyst
- Proteção de rotas baseada em autenticação

### 📊 Módulo de Análise de Demos
- **Upload de Ficheiros:** Interface drag & drop para ficheiros .dem
- **Análise Automática:** Processamento de demos com extração de:
  - Estatísticas de jogadores (kills, deaths, ADR, rating, headshot %)
  - Progressão de rounds e score final
  - Estatísticas de armas utilizadas
  - Uso de utilitários (smokes, flashes, HE, molotovs)
  - Heatmaps de posicionamento (simulado)
- **Dashboard Interativo:** Visualizações com gráficos e charts
- **Insights Automáticos:** Sugestões baseadas na performance
- **Comparação de Performance:** Análise individual e de equipa

### 📅 Módulo de Agendamento de Treinos
- **Calendário Semanal:** Interface intuitiva para visualização
- **Sistema de Disponibilidade:** Membros marcam horários livres
- **Criação de Sessões:** Agendamento automático baseado em disponibilidade
- **Gestão de Participantes:** Controlo de quem participa em cada sessão
- **Notificações:** Sistema de alertas para eventos (preparado)

### 🎨 Interface Moderna
- **Design Responsivo:** Compatível com desktop e mobile
- **Navegação Intuitiva:** Menu lateral e superior
- **Componentes Reutilizáveis:** UI consistente em toda a aplicação
- **Tema Profissional:** Cores e tipografia otimizadas para gaming

## 🛠️ Tecnologias Utilizadas

### Backend
- **Flask** - Framework web Python
- **SQLAlchemy** - ORM para base de dados
- **Flask-Login** - Gestão de autenticação
- **Flask-CORS** - Suporte para Cross-Origin requests
- **SQLite** - Base de dados local

### Frontend
- **React** - Biblioteca JavaScript para UI
- **Vite** - Build tool e dev server
- **Recharts** - Biblioteca para gráficos e visualizações
- **Axios** - Cliente HTTP para API calls
- **React Hook Form** - Gestão de formulários
- **Lucide React** - Ícones modernos

### Deployment
- **Manus Platform** - Hosting e deployment automático
- **URL Permanente** - Acesso público via HTTPS

## 📁 Estrutura do Projeto

```
cs2_team_app/
├── backend/
│   ├── src/
│   │   ├── models/
│   │   │   └── user.py          # Modelos de dados (User, Demo, Training, etc.)
│   │   ├── routes/
│   │   │   ├── auth.py          # Rotas de autenticação
│   │   │   ├── demo.py          # Rotas para gestão de demos
│   │   │   └── training.py      # Rotas para agendamento
│   │   ├── static/              # Ficheiros estáticos do frontend
│   │   ├── database/            # Base de dados SQLite
│   │   └── main.py              # Aplicação principal Flask
│   ├── uploads/                 # Ficheiros de demo carregados
│   ├── requirements.txt         # Dependências Python
│   └── venv/                    # Ambiente virtual
└── frontend/
    ├── src/
    │   ├── components/          # Componentes React reutilizáveis
    │   ├── pages/               # Páginas da aplicação
    │   ├── hooks/               # Custom hooks (useAuth)
    │   ├── lib/                 # Utilitários (API client)
    │   └── App.jsx              # Componente principal
    ├── dist/                    # Build de produção
    └── package.json             # Dependências Node.js
```

## 🚀 Como Executar Localmente

### Pré-requisitos
- Python 3.11+
- Node.js 20+
- pnpm

### Backend
```bash
cd cs2_team_app/backend
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou venv\Scripts\activate  # Windows
pip install -r requirements.txt
python src/main.py
```

### Frontend (Desenvolvimento)
```bash
cd cs2_team_app/frontend
pnpm install
pnpm run dev
```

### Build de Produção
```bash
cd cs2_team_app/frontend
pnpm run build
# Os ficheiros são automaticamente copiados para backend/src/static/
```

## 📊 Modelos de Dados

### User
- id, username, email, password_hash
- role (player, captain, analyst)
- created_at, last_login

### Demo
- id, filename, original_filename, file_path
- team_type (own, opponent), map_name
- uploaded_by, uploaded_at, is_analyzed

### DemoAnalysis
- id, demo_id, analysis_data (JSON)
- analyzed_at

### PlayerStats
- id, demo_id, player_name
- kills, deaths, assists, adr, headshot_percentage
- utility_usage (JSON)

### TrainingSession
- id, title, description, start_time, end_time
- session_type (training, scrim, match)
- created_by, participants (many-to-many)

### UserAvailability
- id, user_id, day_of_week, start_time, end_time

## 🔧 APIs Disponíveis

### Autenticação
- `POST /api/auth/register` - Registo de utilizador
- `POST /api/auth/login` - Login
- `POST /api/auth/logout` - Logout
- `GET /api/auth/check` - Verificar sessão

### Demos
- `GET /api/demos/` - Listar demos
- `POST /api/demos/upload` - Upload de demo
- `POST /api/demos/{id}/analyze` - Analisar demo
- `GET /api/demos/{id}/stats` - Obter estatísticas
- `DELETE /api/demos/{id}` - Eliminar demo

### Treinos
- `GET /api/training/sessions` - Listar sessões
- `POST /api/training/sessions` - Criar sessão
- `GET /api/training/availability` - Obter disponibilidades
- `POST /api/training/availability` - Definir disponibilidade

### Utilizadores
- `GET /api/users` - Listar utilizadores

## 🎯 Funcionalidades Implementadas

✅ **Sistema de Autenticação Completo**
✅ **Upload e Análise de Demos**
✅ **Dashboard com Estatísticas Detalhadas**
✅ **Gráficos Interativos (Recharts)**
✅ **Agendamento de Treinos**
✅ **Calendário Semanal**
✅ **Interface Responsiva**
✅ **Deployment em Produção**
✅ **API RESTful Completa**
✅ **Gestão de Utilizadores e Roles**

## 🔮 Funcionalidades Futuras

- **Parser Real de Demos:** Integração com bibliotecas para análise real de ficheiros .dem
- **Heatmaps Visuais:** Mapas interativos com posicionamento de jogadores
- **Sistema de Notificações:** Email e push notifications
- **Análise de Vídeo:** Upload e análise de clips de jogadas
- **Comparação com Pros:** Benchmarking com equipas profissionais
- **Mobile App:** Aplicação nativa para iOS/Android
- **Integração Steam:** Login via Steam e importação automática de demos

## 📝 Notas de Desenvolvimento

### Análise de Demos
Atualmente, a análise de demos é simulada com dados realistas para demonstração. Para implementação real, seria necessário:
- Integrar com bibliotecas como `demoparser2` ou `awpy`
- Processar ficheiros .dem binários do CS2
- Extrair eventos, posições e estatísticas reais

### Base de Dados
A aplicação usa SQLite para simplicidade. Para produção, recomenda-se:
- PostgreSQL ou MySQL para melhor performance
- Redis para cache e sessões
- Backup automático de dados

### Segurança
- Implementar rate limiting
- Validação robusta de inputs
- Encriptação de dados sensíveis
- Auditoria de ações de utilizadores

## 👥 Contribuição

Este projeto foi desenvolvido como uma demonstração completa de uma aplicação web moderna para gestão de equipas de esports. O código está estruturado de forma modular e extensível para facilitar futuras melhorias.

## 📄 Licença

Projeto desenvolvido para fins demonstrativos. Todos os direitos reservados.

---

**Desenvolvido com ❤️ para a comunidade de Counter-Strike 2**

