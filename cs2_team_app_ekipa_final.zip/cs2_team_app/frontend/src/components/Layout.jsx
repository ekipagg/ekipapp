import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Menu, X, Home, BarChart, Upload, Calendar, Target } from 'lucide-react';

function Layout({ children }) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-gray-900 text-gray-100">
      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-64 bg-gray-800 transform ${isSidebarOpen ? 'translate-x-0' : '-translate-x-full'} transition-transform duration-300 ease-in-out
          lg:relative lg:translate-x-0 lg:flex lg:flex-col`}
      >
        <div className="flex items-center justify-between p-4 border-b border-gray-700">
          <div className="flex items-center space-x-3">
            <img src="/logo.jpeg" alt="EKIPA Logo" className="h-10 w-10 rounded-md object-cover" />
            <div>
              <h1 className="text-xl font-bold text-white">EKIPA</h1>
              <p className="text-xs text-gray-400">CS2 Team</p>
            </div>
          </div>
          <button className="lg:hidden" onClick={() => setIsSidebarOpen(false)}>
            <X className="h-6 w-6 text-gray-400" />
          </button>
        </div>
        <nav className="flex-1 p-4 space-y-2">
          <Link
            to="/"
            className="flex items-center px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
            onClick={() => setIsSidebarOpen(false)}
          >
            <Home className="h-5 w-5 mr-3" />
            Dashboard
          </Link>
          <Link
            to="/demos"
            className="flex items-center px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
            onClick={() => setIsSidebarOpen(false)}
          >
            <BarChart className="h-5 w-5 mr-3" />
            Análise de Demos
          </Link>
          <Link
            to="/demos/upload"
            className="flex items-center px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
            onClick={() => setIsSidebarOpen(false)}
          >
            <Upload className="h-5 w-5 mr-3" />
            Upload Demo
          </Link>
          <Link
            to="/training"
            className="flex items-center px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
            onClick={() => setIsSidebarOpen(false)}
          >
            <Calendar className="h-5 w-5 mr-3" />
            Agendamento
          </Link>
          <Link
            to="/tactics"
            className="flex items-center px-4 py-2 rounded-md text-gray-300 hover:bg-gray-700 hover:text-white transition-colors duration-200"
            onClick={() => setIsSidebarOpen(false)}
          >
            <Target className="h-5 w-5 mr-3" />
            Táticas
          </Link>
        </nav>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-gray-800 p-4 flex items-center justify-between lg:justify-end border-b border-gray-700">
          <button className="lg:hidden" onClick={() => setIsSidebarOpen(true)}>
            <Menu className="h-6 w-6 text-gray-400" />
          </button>
          <h2 className="text-xl font-semibold text-white lg:hidden">EKIPA - CS2 Team Manager</h2>
          <div className="flex items-center space-x-4">
            {/* User Info / Logout (placeholder) */}
            <span className="text-gray-300">Bem-vindo, Jogador!</span>
            <button className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors duration-200">
              Logout
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 p-6 overflow-y-auto">
          {children}
        </main>

        {/* Footer */}
        <footer className="bg-gray-800 p-4 text-center text-gray-500 text-sm border-t border-gray-700">
          Made with Manus Create my website
        </footer>
      </div>
    </div>
  );
}

export default Layout;


