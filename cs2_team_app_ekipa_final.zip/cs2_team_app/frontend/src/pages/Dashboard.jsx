import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '../hooks/useAuth.jsx';
import { demosAPI, trainingAPI } from '../lib/api';
import {
  Upload,
  BarChart3,
  Calendar,
  Users,
  Target,
  TrendingUp,
  Clock,
  FileText
} from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState({
    totalDemos: 0,
    analyzedDemos: 0,
    upcomingSessions: 0,
    recentActivity: []
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      // Carregar estatísticas de demos
      const demosResponse = await demosAPI.getDemos({ per_page: 100 });
      const demos = demosResponse.data.demos;
      
      // Carregar sessões de treino
      const sessionsResponse = await trainingAPI.getSessions({
        start_date: new Date().toISOString().split('T')[0]
      });
      const sessions = sessionsResponse.data.sessions;

      setStats({
        totalDemos: demos.length,
        analyzedDemos: demos.filter(demo => demo.is_analyzed).length,
        upcomingSessions: sessions.length,
        recentActivity: [
          ...demos.slice(0, 3).map(demo => ({
            type: 'demo',
            title: `Demo enviado: ${demo.original_filename}`,
            time: demo.uploaded_at,
            status: demo.is_analyzed ? 'analyzed' : 'pending'
          })),
          ...sessions.slice(0, 2).map(session => ({
            type: 'session',
            title: `Sessão: ${session.title}`,
            time: session.start_datetime,
            status: 'scheduled'
          }))
        ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 5)
      });
    } catch (error) {
      console.error('Erro ao carregar dados do dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = [
    {
      title: 'Upload Demo',
      description: 'Enviar novo ficheiro .dem para análise',
      icon: Upload,
      href: '/demos/upload',
      color: 'bg-blue-500'
    },
    {
      title: 'Ver Análises',
      description: 'Consultar análises de demos existentes',
      icon: BarChart3,
      href: '/demos',
      color: 'bg-green-500'
    },
    {
      title: 'Agendar Treino',
      description: 'Criar nova sessão de treino',
      icon: Calendar,
      href: '/training',
      color: 'bg-purple-500'
    },
    {
      title: 'Táticas',
      description: 'Gerir biblioteca de táticas',
      icon: Target,
      href: '/tactics',
      color: 'bg-orange-500'
    }
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-gray-900"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6 bg-gray-900 text-gray-100 min-h-screen">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-white">
          Bem-vindo, {user?.username || 'Jogador'}!
        </h1>
        <p className="text-gray-400">
          Aqui está um resumo da atividade da sua equipa
        </p>
      </div>

      {/* Estatísticas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total de Demos</CardTitle>
            <FileText className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalDemos}</div>
            <p className="text-xs text-gray-400">
              {stats.analyzedDemos} analisados
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Demos Analisados</CardTitle>
            <TrendingUp className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.analyzedDemos}</div>
            <p className="text-xs text-gray-400">
              {stats.totalDemos > 0 ? Math.round((stats.analyzedDemos / stats.totalDemos) * 100) : 0}% do total
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Próximas Sessões</CardTitle>
            <Clock className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.upcomingSessions}</div>
            <p className="text-xs text-gray-400">
              Esta semana
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Função</CardTitle>
            <Users className="h-4 w-4 text-gray-400" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold capitalize">{user?.role || 'N/A'}</div>
            <p className="text-xs text-gray-400">
              Nível de acesso
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Ações Rápidas */}
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Ações Rápidas</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <Link key={action.title} to={action.href}>
                <Card className="bg-gray-800 border-gray-700 text-gray-100 hover:shadow-lg hover:shadow-gray-700 transition-all duration-300 cursor-pointer">
                  <CardHeader>
                    <div className={`w-12 h-12 ${action.color} rounded-lg flex items-center justify-center mb-2`}>
                      <Icon className="h-6 w-6 text-white" />
                    </div>
                    <CardTitle className="text-lg">{action.title}</CardTitle>
                    <CardDescription className="text-gray-400">{action.description}</CardDescription>
                  </CardHeader>
                </Card>
              </Link>
            );
          })}
        </div>
      </div>

      {/* Atividade Recente */}
      <div>
        <h2 className="text-xl font-semibold text-white mb-4">Atividade Recente</h2>
        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardContent className="p-6">
            {stats.recentActivity.length > 0 ? (
              <div className="space-y-4">
                {stats.recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      {activity.type === 'demo' ? (
                        <FileText className="h-5 w-5 text-blue-400" />
                      ) : (
                        <Calendar className="h-5 w-5 text-green-400" />
                      )}
                      <div>
                        <p className="text-sm font-medium">{activity.title}</p>
                        <p className="text-xs text-gray-400">
                          {new Date(activity.time).toLocaleDateString('pt-PT', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </p>
                      </div>
                    </div>
                    <Badge variant={
                      activity.status === 'analyzed' ? 'default' :
                      activity.status === 'pending' ? 'secondary' : 'outline'
                    } className={
                      activity.status === 'analyzed' ? 'bg-green-500 text-white' :
                      activity.status === 'pending' ? 'bg-yellow-500 text-white' : 'bg-blue-500 text-white'
                    }>
                      {activity.status === 'analyzed' ? 'Analisado' :
                       activity.status === 'pending' ? 'Pendente' : 'Agendado'}
                    </Badge>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500 text-center py-8">
                Nenhuma atividade recente
              </p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;


