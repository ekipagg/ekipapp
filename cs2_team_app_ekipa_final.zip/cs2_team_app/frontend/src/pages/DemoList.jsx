import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { demosAPI } from '../lib/api';
import { useAuth } from '../hooks/useAuth.jsx';
import {
  Upload,
  FileText,
  BarChart3,
  Trash2,
  Search,
  Filter,
  Calendar,
  Users,
  Target,
  AlertCircle
} from 'lucide-react';

const DemoList = () => {
  const [demos, setDemos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [analyzing, setAnalyzing] = useState({});
  const { user } = useAuth();

  useEffect(() => {
    loadDemos();
  }, []);

  const loadDemos = async () => {
    try {
      const response = await demosAPI.getDemos();
      setDemos(response.data.demos);
    } catch (error) {
      setError('Erro ao carregar demos');
      console.error('Erro ao carregar demos:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAnalyzeDemo = async (demoId) => {
    setAnalyzing(prev => ({ ...prev, [demoId]: true }));
    try {
      await demosAPI.analyzeDemo(demoId);
      await loadDemos(); // Recarregar a lista
    } catch (error) {
      setError('Erro ao analisar demo');
    } finally {
      setAnalyzing(prev => ({ ...prev, [demoId]: false }));
    }
  };

  const handleDeleteDemo = async (demoId) => {
    if (!window.confirm('Tem certeza que deseja eliminar este demo?')) {
      return;
    }

    try {
      await demosAPI.deleteDemo(demoId);
      await loadDemos();
    } catch (error) {
      setError('Erro ao eliminar demo');
    }
  };

  const filteredDemos = demos.filter(demo => {
    const matchesSearch = demo.original_filename.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         demo.map_name?.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFilter = filterType === 'all' || demo.team_type === filterType;
    return matchesSearch && matchesFilter;
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6 bg-gray-900 text-gray-100 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Análise de Demos</h1>
          <p className="text-gray-400">
            Gerir e analisar demos da equipa
          </p>
        </div>
        <Link to="/demos/upload">
          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
            <Upload className="h-4 w-4 mr-2" />
            Upload Demo
          </Button>
        </Link>
      </div>

      {error && (
        <Alert variant="destructive" className="bg-red-900 text-red-200 border-red-700 mb-4">
          <AlertCircle className="h-4 w-4 text-red-400" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Filtros */}
      <Card className="bg-gray-800 border-gray-700 text-gray-100">
        <CardContent className="pt-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Pesquisar por nome do ficheiro ou mapa..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400"
                />
              </div>
            </div>
            <div className="sm:w-48">
              <Select value={filterType} onValueChange={setFilterType}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-100">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-100">
                  <SelectItem value="all">Todos os Demos</SelectItem>
                  <SelectItem value="own">Nossa Equipa</SelectItem>
                  <SelectItem value="opponent">Adversários</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Lista de Demos */}
      {filteredDemos.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardContent className="pt-6">
            <div className="text-center py-12">
              <FileText className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-white mb-2">
                {demos.length === 0 ? 'Nenhum demo encontrado' : 'Nenhum demo corresponde aos filtros'}
              </h3>
              <p className="text-gray-400 mb-4">
                {demos.length === 0 
                  ? 'Comece por enviar o seu primeiro demo para análise.'
                  : 'Tente ajustar os filtros de pesquisa.'
                }
              </p>
              {demos.length === 0 && (
                <Link to="/demos/upload">
                  <Button className="bg-blue-600 hover:bg-blue-700 text-white">
                    <Upload className="h-4 w-4 mr-2" />
                    Enviar Primeiro Demo
                  </Button>
                </Link>
              )}
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-4">
          {filteredDemos.map((demo) => (
            <Card key={demo.id} className="bg-gray-800 border-gray-700 text-gray-100 hover:shadow-lg hover:shadow-gray-700 transition-all duration-300">
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between">
                  <div className="flex-1 mb-4 md:mb-0">
                    <div className="flex flex-wrap items-center space-x-3 mb-2">
                      <FileText className="h-5 w-5 text-blue-400" />
                      <h3 className="text-lg font-medium text-white">
                        {demo.original_filename}
                      </h3>
                      <Badge className={demo.team_type === 'own' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}>
                        {demo.team_type === 'own' ? 'Nossa Equipa' : 'Adversário'}
                      </Badge>
                      {demo.is_analyzed && (
                        <Badge className="bg-purple-600 text-white">
                          Analisado
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex flex-wrap items-center space-x-6 text-sm text-gray-400">
                      {demo.map_name && (
                        <div className="flex items-center space-x-1">
                          <Target className="h-4 w-4" />
                          <span>{demo.map_name}</span>
                        </div>
                      )}
                      <div className="flex items-center space-x-1">
                        <Calendar className="h-4 w-4" />
                        <span>
                          {new Date(demo.uploaded_at).toLocaleDateString('pt-PT', {
                            day: '2-digit',
                            month: '2-digit',
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Users className="h-4 w-4" />
                        <span>Enviado por: {demo.uploaded_by}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {demo.is_analyzed ? (
                      <Link to={`/demos/${demo.id}/stats`}>
                        <Button variant="outline" size="sm" className="border-blue-600 text-blue-400 hover:bg-blue-900 hover:text-white">
                          <BarChart3 className="h-4 w-4 mr-2" />
                          Ver Análise
                        </Button>
                      </Link>
                    ) : (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleAnalyzeDemo(demo.id)}
                        disabled={analyzing[demo.id]}
                        className="border-green-600 text-green-400 hover:bg-green-900 hover:text-white"
                      >
                        <BarChart3 className="h-4 w-4 mr-2" />
                        {analyzing[demo.id] ? 'A analisar...' : 'Analisar'}
                      </Button>
                    )}

                    {(user?.role === 'captain' || user?.role === 'analyst' || demo.uploaded_by === user?.id) && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDeleteDemo(demo.id)}
                        className="border-red-600 text-red-400 hover:bg-red-900 hover:text-white"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Estatísticas Resumo */}
      {demos.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Total de Demos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{demos.length}</div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Demos Analisados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {demos.filter(d => d.is_analyzed).length}
              </div>
              <p className="text-xs text-gray-400">
                {demos.length > 0 ? Math.round((demos.filter(d => d.is_analyzed).length / demos.length) * 100) : 0}% do total
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium">Nossa Equipa</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">
                {demos.filter(d => d.team_type === 'own').length}
              </div>
              <p className="text-xs text-gray-400">
                vs {demos.filter(d => d.team_type === 'opponent').length} adversários
              </p>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default DemoList;


