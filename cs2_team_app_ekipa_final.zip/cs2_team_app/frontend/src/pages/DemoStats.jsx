import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { demosAPI } from '../lib/api';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar
} from 'recharts';
import {
  ArrowLeft,
  Target,
  Crosshair,
  Zap,
  Shield,
  TrendingUp,
  Users,
  MapPin,
  Clock,
  AlertCircle
} from 'lucide-react';

const DemoStats = () => {
  const { demoId } = useParams();
  const [demo, setDemo] = useState(null);
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadDemoStats();
  }, [demoId]);

  const loadDemoStats = async () => {
    try {
      const response = await demosAPI.getDemoStats(demoId);
      setDemo(response.data.demo);
      setStats(response.data.stats);
    } catch (error) {
      setError('Erro ao carregar estatísticas do demo');
      console.error('Erro ao carregar estatísticas:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive" className="bg-red-900 text-red-200 border-red-700">
        <AlertCircle className="h-4 w-4 text-red-400" />
        <AlertDescription>{error}</AlertDescription>
      </Alert>
    );
  }

  if (!demo || !stats) {
    return (
      <Alert className="bg-yellow-900 text-yellow-200 border-yellow-700">
        <AlertCircle className="h-4 w-4 text-yellow-400" />
        <AlertDescription>Demo não encontrado ou ainda não analisado.</AlertDescription>
      </Alert>
    );
  }

  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  const playerPerformanceData = stats.players?.map(player => ({
    name: player.name,
    kills: player.kills,
    deaths: player.deaths,
    assists: player.assists,
    adr: player.adr,
    rating: player.rating,
    headshot_percentage: player.headshot_percentage
  })) || [];

  const roundsData = stats.rounds?.map((round, index) => ({
    round: index + 1,
    team_score: round.team_score,
    enemy_score: round.enemy_score,
    won: round.won
  })) || [];

  const weaponData = stats.weapon_stats ? Object.entries(stats.weapon_stats).map(([weapon, data]) => ({
    name: weapon,
    kills: data.kills,
    accuracy: data.accuracy
  })) : [];

  const utilityData = stats.utility_usage ? [
    { name: 'Smokes', value: stats.utility_usage.smokes },
    { name: 'Flashes', value: stats.utility_usage.flashes },
    { name: 'HE Grenades', value: stats.utility_usage.he_grenades },
    { name: 'Molotovs', value: stats.utility_usage.molotovs }
  ] : [];

  return (
    <div className="space-y-6 p-6 bg-gray-900 text-gray-100 min-h-screen">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-4">
          <Link to="/demos">
            <Button variant="outline" size="sm" className="border-gray-600 text-gray-100 hover:bg-gray-700">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-white">{demo.original_filename}</h1>
            <div className="flex items-center space-x-4 text-sm text-gray-400">
              <div className="flex items-center space-x-1">
                <MapPin className="h-4 w-4" />
                <span>{demo.map_name || 'Mapa desconhecido'}</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="h-4 w-4" />
                <span>{new Date(demo.uploaded_at).toLocaleDateString('pt-PT')}</span>
              </div>
              <Badge className={demo.team_type === 'own' ? 'bg-green-600 text-white' : 'bg-red-600 text-white'}>
                {demo.team_type === 'own' ? 'Nossa Equipa' : 'Adversário'}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Resumo Geral */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Target className="h-4 w-4 mr-2 text-gray-400" />
              Score Final
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {stats.final_score?.team_score || 0} - {stats.final_score?.enemy_score || 0}
            </div>
            <p className="text-xs text-gray-400">
              {stats.final_score?.result || 'Resultado desconhecido'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Crosshair className="h-4 w-4 mr-2 text-gray-400" />
              Total de Kills
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.total_kills || 0}</div>
            <p className="text-xs text-gray-400">
              {stats.total_headshots || 0} headshots ({((stats.total_headshots / stats.total_kills) * 100).toFixed(1)}%)
            </p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Zap className="h-4 w-4 mr-2 text-gray-400" />
              ADR Médio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.average_adr?.toFixed(1) || '0.0'}</div>
            <p className="text-xs text-gray-400">Damage por round</p>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium flex items-center">
              <Shield className="h-4 w-4 mr-2 text-gray-400" />
              Rating Médio
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.average_rating?.toFixed(2) || '0.00'}</div>
            <p className="text-xs text-gray-400">Performance geral</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs com Análises Detalhadas */}
      <Tabs defaultValue="players" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5 bg-gray-800 border-gray-700">
          <TabsTrigger value="players" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white text-gray-300">Jogadores</TabsTrigger>
          <TabsTrigger value="rounds" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white text-gray-300">Rounds</TabsTrigger>
          <TabsTrigger value="weapons" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white text-gray-300">Armas</TabsTrigger>
          <TabsTrigger value="utility" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white text-gray-300">Utilitários</TabsTrigger>
          <TabsTrigger value="heatmap" className="data-[state=active]:bg-gray-700 data-[state=active]:text-white text-gray-300">Heatmap</TabsTrigger>
        </TabsList>

        <TabsContent value="players" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Performance dos Jogadores</CardTitle>
              <CardDescription className="text-gray-400">
                Estatísticas individuais de cada jogador
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={playerPerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4a4a4a" />
                    <XAxis dataKey="name" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', color: '#e5e7eb' }} itemStyle={{ color: '#e5e7eb' }} />
                    <Bar dataKey="kills" fill="#8884d8" name="Kills" />
                    <Bar dataKey="deaths" fill="#82ca9d" name="Deaths" />
                    <Bar dataKey="assists" fill="#ffc658" name="Assists" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Rating vs ADR</CardTitle>
              <CardDescription className="text-gray-400">
                Comparação entre rating e damage por round
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={playerPerformanceData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4a4a4a" />
                    <XAxis dataKey="name" stroke="#9ca3af" />
                    <YAxis yAxisId="left" stroke="#9ca3af" />
                    <YAxis yAxisId="right" orientation="right" stroke="#9ca3af" />
                    <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', color: '#e5e7eb' }} itemStyle={{ color: '#e5e7eb' }} />
                    <Line yAxisId="left" type="monotone" dataKey="rating" stroke="#8884d8" name="Rating" />
                    <Line yAxisId="right" type="monotone" dataKey="adr" stroke="#82ca9d" name="ADR" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="rounds" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Progressão dos Rounds</CardTitle>
              <CardDescription className="text-gray-400">
                Evolução do score ao longo da partida
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={roundsData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4a4a4a" />
                    <XAxis dataKey="round" stroke="#9ca3af" />
                    <YAxis stroke="#9ca3af" />
                    <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', color: '#e5e7eb' }} itemStyle={{ color: '#e5e7eb' }} />
                    <Line type="monotone" dataKey="team_score" stroke="#8884d8" name="Nossa Equipa" />
                    <Line type="monotone" dataKey="enemy_score" stroke="#82ca9d" name="Adversários" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="weapons" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Estatísticas de Armas</CardTitle>
              <CardDescription className="text-gray-400">
                Kills e precisão por tipo de arma
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={weaponData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#4a4a4a" />
                    <XAxis dataKey="name" stroke="#9ca3af" />
                    <YAxis yAxisId="left" stroke="#9ca3af" />
                    <YAxis yAxisId="right" orientation="right" stroke="#9ca3af" />
                    <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', color: '#e5e7eb' }} itemStyle={{ color: '#e5e7eb' }} />
                    <Bar yAxisId="left" dataKey="kills" fill="#8884d8" name="Kills" />
                    <Bar yAxisId="right" dataKey="accuracy" fill="#82ca9d" name="Precisão %" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="utility" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Uso de Utilitários</CardTitle>
              <CardDescription className="text-gray-400">
                Distribuição do uso de granadas e utilitários
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={utilityData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="value"
                    >
                      {utilityData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: '#374151', border: 'none', color: '#e5e7eb' }} itemStyle={{ color: '#e5e7eb' }} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="heatmap" className="space-y-4">
          <Card className="bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Heatmap de Posições</CardTitle>
              <CardDescription className="text-gray-400">
                Mapa de calor das posições mais frequentes dos jogadores
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-96 bg-gray-700 rounded-lg flex items-center justify-center">
                <div className="text-center">
                  <MapPin className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-white mb-2">Heatmap em Desenvolvimento</h3>
                  <p className="text-gray-400">
                    O mapa de calor das posições será implementado com dados de coordenadas do demo.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Insights e Sugestões */}
      <Card className="bg-gray-800 border-gray-700 text-gray-100">
        <CardHeader>
          <CardTitle className="flex items-center text-white">
            <TrendingUp className="h-5 w-5 mr-2 text-gray-400" />
            Insights e Sugestões
          </CardTitle>
          <CardDescription className="text-gray-400">
            Análise automática e recomendações baseadas na performance
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {stats.insights?.map((insight, index) => (
              <div key={index} className="p-4 bg-blue-900 rounded-lg border-l-4 border-blue-500">
                <h4 className="font-medium text-blue-200">{insight.title}</h4>
                <p className="text-blue-300 text-sm mt-1">{insight.description}</p>
              </div>
            )) || (
              <div className="p-4 bg-gray-700 rounded-lg">
                <p className="text-gray-400">
                  Insights serão gerados automaticamente após a análise completa do demo.
                </p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DemoStats;


