import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Progress } from '@/components/ui/progress';
import { demosAPI } from '../lib/api';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';

const uploadSchema = z.object({
  team_type: z.enum(['own', 'opponent']),
  file: z.any().refine((files) => files?.length > 0, 'Ficheiro é obrigatório')
    .refine((files) => files?.[0]?.name?.endsWith('.dem'), 'Apenas ficheiros .dem são permitidos')
    .refine((files) => files?.[0]?.size <= 1024 * 1024 * 1024, 'Ficheiro deve ter menos de 1GB'),
});

const DemoUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(uploadSchema),
    defaultValues: {
      team_type: 'own',
    },
  });

  const selectedFile = watch('file');

  const onSubmit = async (data) => {
    setUploading(true);
    setError('');
    setUploadProgress(0);

    try {
      const formData = new FormData();
      formData.append('file', data.file[0]);
      formData.append('team_type', data.team_type);

      // Simular progresso de upload
      const progressInterval = setInterval(() => {
        setUploadProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return prev;
          }
          return prev + 10;
        });
      }, 200);

      const response = await demosAPI.uploadDemo(formData);
      
      clearInterval(progressInterval);
      setUploadProgress(100);
      setUploadSuccess(true);

      setTimeout(() => {
        navigate('/demos');
      }, 2000);

    } catch (error) {
      setError(error.response?.data?.error || 'Erro no upload do ficheiro');
    } finally {
      setUploading(false);
    }
  };

  if (uploadSuccess) {
    return (
      <div className="max-w-2xl mx-auto p-6 bg-gray-900 text-gray-100 rounded-lg shadow-lg">
        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardContent className="pt-6">
            <div className="text-center">
              <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-white mb-2">Upload Concluído!</h2>
              <p className="text-gray-400 mb-4">
                O seu demo foi enviado com sucesso e está pronto para análise.
              </p>
              <Button onClick={() => navigate('/demos')} className="bg-blue-600 hover:bg-blue-700 text-white">
                Ver Demos
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6 bg-gray-900 text-gray-100 rounded-lg shadow-lg">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-white">Upload de Demo</h1>
        <p className="text-gray-400">
          Envie ficheiros .dem para análise detalhada de performance
        </p>
      </div>

      <Card className="bg-gray-800 border-gray-700 text-gray-100">
        <CardHeader>
          <CardTitle className="text-white">Enviar Novo Demo</CardTitle>
          <CardDescription className="text-gray-400">
            Selecione um ficheiro .dem e especifique se é da sua equipa ou do adversário
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            {error && (
              <Alert variant="destructive" className="bg-red-900 text-red-200 border-red-700">
                <AlertCircle className="h-4 w-4 text-red-400" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <div className="space-y-2">
              <Label htmlFor="team_type" className="text-gray-300">Tipo de Equipa</Label>
              <Select onValueChange={(value) => setValue('team_type', value)} defaultValue="own">
                <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-100">
                  <SelectValue placeholder="Selecione o tipo de equipa" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600 text-gray-100">
                  <SelectItem value="own">Nossa Equipa</SelectItem>
                  <SelectItem value="opponent">Equipa Adversária</SelectItem>
                </SelectContent>
              </Select>
              {errors.team_type && (
                <p className="text-sm text-red-400">{errors.team_type.message}</p>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="file" className="text-gray-300">Ficheiro Demo (.dem)</Label>
              <div className="border-2 border-dashed border-gray-600 rounded-lg p-6 text-center hover:border-gray-500 transition-colors">
                <input
                  id="file"
                  type="file"
                  accept=".dem"
                  {...register('file')}
                  className="hidden"
                />
                <label htmlFor="file" className="cursor-pointer block">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-lg font-medium text-white mb-2">
                    Clique para selecionar um ficheiro
                  </p>
                  <p className="text-sm text-gray-400">
                    Ou arraste e largue o ficheiro .dem aqui
                  </p>
                  <p className="text-xs text-gray-500 mt-2">
                    Máximo 1GB
                  </p>
                </label>
              </div>
              
              {selectedFile && selectedFile[0] && (
                <div className="flex items-center space-x-2 p-3 bg-gray-700 rounded-lg">
                  <FileText className="h-5 w-5 text-blue-400" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-100">{selectedFile[0].name}</p>
                    <p className="text-xs text-gray-400">
                      {(selectedFile[0].size / (1024 * 1024)).toFixed(2)} MB
                    </p>
                  </div>
                </div>
              )}
              
              {errors.file && (
                <p className="text-sm text-red-400">{errors.file.message}</p>
              )}
            </div>

            {uploading && (
              <div className="space-y-2">
                <div className="flex justify-between text-sm text-gray-300">
                  <span>A enviar...</span>
                  <span>{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="w-full bg-gray-700 [&>*]:bg-blue-500" />
              </div>
            )}

            <div className="flex space-x-4">
              <Button type="submit" disabled={uploading} className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                {uploading ? 'A enviar...' : 'Enviar Demo'}
              </Button>
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => navigate('/demos')}
                disabled={uploading}
                className="flex-1 border-gray-600 text-gray-100 hover:bg-gray-700"
              >
                Cancelar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Card className="mt-6 bg-gray-800 border-gray-700 text-gray-100">
        <CardHeader>
          <CardTitle className="text-white">Informações sobre Demos</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3 text-sm">
            <div>
              <h4 className="font-medium text-gray-200">Formatos Suportados:</h4>
              <p className="text-gray-400">Apenas ficheiros .dem do Counter-Strike 2</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-200">Tamanho Máximo:</h4>
              <p className="text-gray-400">1GB por ficheiro</p>
            </div>
            <div>
              <h4 className="font-medium text-gray-200">Análise Automática:</h4>
              <p className="text-gray-400">
                Após o upload, o demo será automaticamente analisado para extrair estatísticas, 
                heatmaps e táticas utilizadas.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default DemoUpload;


