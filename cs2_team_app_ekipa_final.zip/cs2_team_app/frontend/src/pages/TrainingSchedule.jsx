import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { trainingAPI, usersAPI } from '../lib/api';
import { useAuth } from '../hooks/useAuth.jsx';
import { format, addDays, startOfWeek, endOfWeek } from 'date-fns';
import { pt } from 'date-fns/locale';
import {
  Calendar as CalendarIcon,
  Clock,
  Users,
  Plus,
  Edit,
  Trash2,
  Target,
  Gamepad2,
  Trophy,
  AlertCircle,
  CheckCircle
} from 'lucide-react';

const sessionSchema = z.object({
  title: z.string().min(1, 'Título é obrigatório'),
  description: z.string().optional(),
  session_type: z.enum(['training', 'scrim', 'tournament']),
  start_datetime: z.string().min(1, 'Data e hora de início são obrigatórias'),
  end_datetime: z.string().min(1, 'Hora de fim é obrigatória'),
  participant_ids: z.array(z.number()).optional(),
});

const availabilitySchema = z.object({
  date: z.string().min(1, 'Data é obrigatória'),
  start_time: z.string().min(1, 'Hora de início é obrigatória'),
  end_time: z.string().min(1, 'Hora de fim é obrigatória'),
});

const TrainingSchedule = () => {
  const [sessions, setSessions] = useState([]);
  const [users, setUsers] = useState([]);
  const [availabilities, setAvailabilities] = useState([]);
  const [suggestions, setSuggestions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [showAvailabilityForm, setShowAvailabilityForm] = useState(false);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('week'); // 'week' or 'month'
  const { user } = useAuth();

  const sessionForm = useForm({
    resolver: zodResolver(sessionSchema),
    defaultValues: {
      session_type: 'training',
      participant_ids: [],
    },
  });

  const availabilityForm = useForm({
    resolver: zodResolver(availabilitySchema),
  });

  useEffect(() => {
    loadData();
  }, [selectedDate]);

  const loadData = async () => {
    try {
      const startDate = startOfWeek(selectedDate, { weekStartsOn: 1 });
      const endDate = endOfWeek(selectedDate, { weekStartsOn: 1 });

      const [sessionsResponse, usersResponse, availabilityResponse] = await Promise.all([
        trainingAPI.getSessions({
          start_date: format(startDate, 'yyyy-MM-dd'),
          end_date: format(endDate, 'yyyy-MM-dd'),
        }),
        usersAPI.getUsers(),
        trainingAPI.getAvailability({
          start_date: format(startDate, 'yyyy-MM-dd'),
          end_date: format(endDate, 'yyyy-MM-dd'),
        }),
      ]);

      setSessions(sessionsResponse.data.sessions);
      setUsers(usersResponse.data.users || []);
      setAvailabilities(availabilityResponse.data.availabilities || []);
    } catch (error) {
      setError('Erro ao carregar dados');
      console.error('Erro ao carregar dados:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateSession = async (data) => {
    try {
      await trainingAPI.createSession(data);
      await loadData();
      setShowCreateForm(false);
      sessionForm.reset();
    } catch (error) {
      setError('Erro ao criar sessão');
    }
  };

  const handleSetAvailability = async (data) => {
    try {
      await trainingAPI.setAvailability(data);
      await loadData();
      setShowAvailabilityForm(false);
      availabilityForm.reset();
    } catch (error) {
      setError('Erro ao definir disponibilidade');
    }
  };

  const handleSuggestSchedule = async (date) => {
    try {
      const response = await trainingAPI.suggestSchedule({
        date: format(date, 'yyyy-MM-dd'),
        duration_hours: 2,
      });
      setSuggestions(response.data.suggestions);
    } catch (error) {
      setError('Erro ao sugerir horários');
    }
  };

  const getSessionIcon = (type) => {
    switch (type) {
      case 'training': return <Target className="h-4 w-4" />;
      case 'scrim': return <Gamepad2 className="h-4 w-4" />;
      case 'tournament': return <Trophy className="h-4 w-4" />;
      default: return <CalendarIcon className="h-4 w-4" />;
    }
  };

  const getSessionColor = (type) => {
    switch (type) {
      case 'training': return 'bg-blue-600';
      case 'scrim': return 'bg-green-600';
      case 'tournament': return 'bg-purple-600';
      default: return 'bg-gray-600';
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64 bg-gray-900">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-6 bg-gray-900 text-gray-100 min-h-screen">
      {/* Header */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-white">Agendamento de Treinos</h1>
          <p className="text-gray-400">
            Gerir disponibilidades e sessões de treino da equipa
          </p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => setShowAvailabilityForm(true)} className="border-gray-600 text-gray-100 hover:bg-gray-700">
            <Clock className="h-4 w-4 mr-2" />
            Definir Disponibilidade
          </Button>
          {(user?.role === 'captain' || user?.role === 'analyst') && (
            <Button onClick={() => setShowCreateForm(true)} className="bg-blue-600 hover:bg-blue-700 text-white">
              <Plus className="h-4 w-4 mr-2" />
              Nova Sessão
            </Button>
          )}
        </div>
      </div>

      {error && (
        <Alert variant="destructive" className="bg-red-900 text-red-200 border-red-700 mb-4">
          <AlertCircle className="h-4 w-4 text-red-400" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {/* Navegação do Calendário */}
      <Card className="bg-gray-800 border-gray-700 text-gray-100">
        <CardContent className="pt-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-4 mb-4 md:mb-0">
              <Button
                variant="outline"
                onClick={() => setSelectedDate(addDays(selectedDate, -7))}
                className="border-gray-600 text-gray-100 hover:bg-gray-700"
              >
                ← Semana Anterior
              </Button>
              <h2 className="text-lg font-semibold text-white">
                {format(startOfWeek(selectedDate, { weekStartsOn: 1 }), 'dd MMM', { locale: pt })} - {' '}
                {format(endOfWeek(selectedDate, { weekStartsOn: 1 }), 'dd MMM yyyy', { locale: pt })}
              </h2>
              <Button
                variant="outline"
                onClick={() => setSelectedDate(addDays(selectedDate, 7))}
                className="border-gray-600 text-gray-100 hover:bg-gray-700"
              >
                Próxima Semana →
              </Button>
            </div>
            <Button
              variant="outline"
              onClick={() => setSelectedDate(new Date())}
              className="border-gray-600 text-gray-100 hover:bg-gray-700"
            >
              Hoje
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Calendário Semanal */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-7 gap-4">
        {Array.from({ length: 7 }, (_, i) => {
          const date = addDays(startOfWeek(selectedDate, { weekStartsOn: 1 }), i);
          const daySessions = sessions.filter(session => 
            format(new Date(session.start_datetime), 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
          );
          const dayAvailabilities = availabilities.filter(av => 
            av.date === format(date, 'yyyy-MM-dd')
          );

          return (
            <Card key={i} className="min-h-[300px] bg-gray-800 border-gray-700 text-gray-100">
              <CardHeader className="pb-2">
                <CardTitle className="text-sm text-gray-300">
                  {format(date, 'EEE', { locale: pt })}
                </CardTitle>
                <CardDescription className="text-lg font-semibold text-white">
                  {format(date, 'dd')}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-2">
                {/* Sessões */}
                {daySessions.map((session) => (
                  <div
                    key={session.id}
                    className={`p-2 rounded text-white text-xs ${getSessionColor(session.session_type)}`}
                  >
                    <div className="flex items-center space-x-1 mb-1">
                      {getSessionIcon(session.session_type)}
                      <span className="font-medium">{session.title}</span>
                    </div>
                    <div>
                      {format(new Date(session.start_datetime), 'HH:mm')} - {' '}
                      {format(new Date(session.end_datetime), 'HH:mm')}
                    </div>
                  </div>
                ))}

                {/* Disponibilidades */}
                {dayAvailabilities.map((availability) => (
                  <div
                    key={availability.id}
                    className="p-2 rounded bg-gray-700 text-xs text-gray-200"
                  >
                    <div className="flex items-center space-x-1">
                      <Users className="h-3 w-3 text-gray-400" />
                      <span>Disponível</span>
                    </div>
                    <div className="text-gray-400">
                      {availability.start_time} - {availability.end_time}
                    </div>
                  </div>
                ))}

                {/* Botão para sugerir horários */}
                {(user?.role === 'captain' || user?.role === 'analyst') && (
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full text-xs text-blue-400 hover:bg-gray-700 hover:text-blue-300"
                    onClick={() => handleSuggestSchedule(date)}
                  >
                    Sugerir Horários
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Sugestões de Horários */}
      {suggestions.length > 0 && (
        <Card className="bg-gray-800 border-gray-700 text-gray-100">
          <CardHeader>
            <CardTitle className="text-white">Sugestões de Horários</CardTitle>
            <CardDescription className="text-gray-400">
              Baseado nas disponibilidades da equipa
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-3">
              {suggestions.map((suggestion, index) => (
                <div key={index} className="flex items-center justify-between p-3 border border-gray-700 rounded-lg bg-gray-700">
                  <div>
                    <div className="font-medium text-white">
                      {suggestion.start_time} - {suggestion.end_time}
                    </div>
                    <div className="text-sm text-gray-400">
                      {suggestion.available_users} jogadores disponíveis
                    </div>
                  </div>
                  <Button
                    size="sm"
                    onClick={() => {
                      sessionForm.setValue('start_datetime', `${format(selectedDate, 'yyyy-MM-dd')}T${suggestion.start_time}`);
                      sessionForm.setValue('end_datetime', `${format(selectedDate, 'yyyy-MM-dd')}T${suggestion.end_time}`);
                      sessionForm.setValue('participant_ids', suggestion.user_ids);
                      setShowCreateForm(true);
                    }}
                    className="bg-blue-600 hover:bg-blue-700 text-white"
                  >
                    Usar Sugestão
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Modal Criar Sessão */}
      {showCreateForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Nova Sessão de Treino</CardTitle>
              <CardDescription className="text-gray-400">
                Criar uma nova sessão para a equipa
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={sessionForm.handleSubmit(handleCreateSession)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="title" className="text-gray-300">Título</Label>
                  <Input
                    id="title"
                    {...sessionForm.register('title')}
                    placeholder="Ex: Treino de Táticas"
                    className="bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400"
                  />
                  {sessionForm.formState.errors.title && (
                    <p className="text-sm text-red-400">{sessionForm.formState.errors.title.message}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="session_type" className="text-gray-300">Tipo de Sessão</Label>
                  <Select onValueChange={(value) => sessionForm.setValue('session_type', value)} defaultValue="training">
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-gray-100">
                      <SelectValue placeholder="Selecione o tipo" />
                    </SelectTrigger>
                    <SelectContent className="bg-gray-700 border-gray-600 text-gray-100">
                      <SelectItem value="training">Treino</SelectItem>
                      <SelectItem value="scrim">Scrim</SelectItem>
                      <SelectItem value="tournament">Torneio</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start_datetime" className="text-gray-300">Início</Label>
                    <Input
                      id="start_datetime"
                      type="datetime-local"
                      {...sessionForm.register('start_datetime')}
                      className="bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end_datetime" className="text-gray-300">Fim</Label>
                    <Input
                      id="end_datetime"
                      type="datetime-local"
                      {...sessionForm.register('end_datetime')}
                      className="bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-gray-300">Descrição (opcional)</Label>
                  <Textarea
                    id="description"
                    {...sessionForm.register('description')}
                    placeholder="Detalhes sobre a sessão..."
                    className="bg-gray-700 border-gray-600 text-gray-100 placeholder-gray-400"
                  />
                </div>

                <div className="flex space-x-2">
                  <Button type="submit" className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                    Criar Sessão
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowCreateForm(false)}
                    className="flex-1 border-gray-600 text-gray-100 hover:bg-gray-700"
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Modal Definir Disponibilidade */}
      {showAvailabilityForm && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <Card className="w-full max-w-md bg-gray-800 border-gray-700 text-gray-100">
            <CardHeader>
              <CardTitle className="text-white">Definir Disponibilidade</CardTitle>
              <CardDescription className="text-gray-400">
                Indique quando está disponível para treinos
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={availabilityForm.handleSubmit(handleSetAvailability)} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="date" className="text-gray-300">Data</Label>
                  <Input
                    id="date"
                    type="date"
                    {...availabilityForm.register('date')}
                    className="bg-gray-700 border-gray-600 text-gray-100"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="start_time" className="text-gray-300">Hora de Início</Label>
                    <Input
                      id="start_time"
                      type="time"
                      {...availabilityForm.register('start_time')}
                      className="bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="end_time" className="text-gray-300">Hora de Fim</Label>
                    <Input
                      id="end_time"
                      type="time"
                      {...availabilityForm.register('end_time')}
                      className="bg-gray-700 border-gray-600 text-gray-100"
                    />
                  </div>
                </div>

                <div className="flex space-x-2">
                  <Button type="submit" className="flex-1 bg-green-600 hover:bg-green-700 text-white">
                    Definir Disponibilidade
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAvailabilityForm(false)}
                    className="flex-1 border-gray-600 text-gray-100 hover:bg-gray-700"
                  >
                    Cancelar
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default TrainingSchedule;


