import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './hooks/useAuth.jsx';
// import ProtectedRoute from './components/ProtectedRoute.jsx';
import Layout from './components/Layout.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Dashboard from './pages/Dashboard.jsx';
import DemoUpload from './pages/DemoUpload.jsx';
import DemoList from './pages/DemoList.jsx';
import DemoStats from './pages/DemoStats.jsx';
import TrainingSchedule from './pages/TrainingSchedule.jsx';

function App() {
  return (
    <AuthProvider>
      <Router>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/" element={
            // <ProtectedRoute>
              <Layout>
                <Dashboard />
              </Layout>
            // </ProtectedRoute>
          } />
          <Route path="/demos" element={
            // <ProtectedRoute>
              <Layout>
                <DemoList />
              </Layout>
            // </ProtectedRoute>
          } />
          <Route path="/demos/upload" element={
            // <ProtectedRoute>
              <Layout>
                <DemoUpload />
              </Layout>
            // </ProtectedRoute>
          } />
          <Route path="/demos/:demoId/stats" element={
            // <ProtectedRoute>
              <Layout>
                <DemoStats />
              </Layout>
            // </ProtectedRoute>
          } />
          <Route path="/training" element={
            // <ProtectedRoute>
              <Layout>
                <TrainingSchedule />
              </Layout>
            // </ProtectedRoute>
          } />
        </Routes>
      </Router>
    </AuthProvider>
  );
}

export default App;


